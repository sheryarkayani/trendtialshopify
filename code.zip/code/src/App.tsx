import HomePage from './components/HomePage'

import "./styles/globals.css";  // Adjust path based on your project


function App() {
  return (
    <HomePage />
  )
}

export default App